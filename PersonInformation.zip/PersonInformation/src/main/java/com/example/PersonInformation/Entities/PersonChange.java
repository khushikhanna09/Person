package com.example.PersonInformation.Entities;

public class PersonChange {
    public String firstname;
    public String lastname;
    public  Integer age;
    public String occupation;
    public Integer ssnnum;
}
