package com.example.PersonInformation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonInformationApplicationTests {

	@Test
	void contextLoads() {
	}

}
